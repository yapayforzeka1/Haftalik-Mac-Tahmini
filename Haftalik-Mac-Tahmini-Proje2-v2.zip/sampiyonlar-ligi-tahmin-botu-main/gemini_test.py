import os
from google import genai
from google.genai import types


api_key = os.environ["GEMINI_API_KEY"]
client = genai.Client(api_key=api_key)

response = client.models.generate_content(
    model="gemini-3.7-flash",
    contents="Sadece 'GEMINI ÇALIŞIYOR' yaz. Başka hiçbir şey yazma.",
    config=types.GenerateContentConfig(max_output_tokens=20),
)

print(response.text)
