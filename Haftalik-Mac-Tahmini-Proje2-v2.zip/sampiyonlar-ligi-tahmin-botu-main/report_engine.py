from __future__ import annotations

from typing import Any

from consensus_engine import outcome_label


def build_telegram_message(record: dict[str, Any]) -> str:
    home = record["home_team"]
    away = record["away_team"]
    consensus = record["consensus"]
    research = record.get("research", {})
    votes = record.get("ai_votes", [])

    lines = [
        "🏆 HAFTALIK MAÇ ANALİZİ",
        "",
        f"⚽ {home} - {away}",
        f"🇹🇷 Maç saati: {record['match_time']}",
        "",
        "🤖 AI KONSENSÜSÜ",
        f"Sonuç: {outcome_label(consensus['outcome'], home, away)} — {consensus['outcome_share']}% ({consensus['outcome_votes']}/{consensus['successful_ai']} AI)",
        f"Skor: {consensus['score']} — {consensus['score_share']}% ({consensus['score_votes']}/{consensus['successful_ai']} AI)",
        "",
    ]

    for vote in votes:
        if vote["success"]:
            result = vote["result"]
            lines.append(f"• {vote['model']}: {outcome_label(result['outcome'], home, away)} / {result['score']}")
        else:
            lines.append(f"• {vote['model']}: ⚠️ başarısız")

    summary = research.get("summary")
    if summary:
        lines += ["", "🔎 ARAŞTIRMA ÖZETİ", summary[:900]]

    reasons = consensus.get("reasons_by_outcome", {}).get(consensus["outcome"], [])
    if reasons:
        lines += ["", "📌 KONSENSÜS NEDENLERİ"]
        lines.extend(f"• {reason}" for reason in reasons[:3])

    conflicts = research.get("conflicts", [])
    if conflicts:
        lines += ["", "⚠️ VERİ ÇELİŞKİLERİ"]
        lines.extend(f"• {item}" for item in conflicts[:2])

    confidence = research.get("research_confidence")
    if confidence:
        lines += ["", f"📚 Araştırma güveni: {confidence}"]

    return "\n".join(lines)


def build_result_message(record: dict[str, Any]) -> str:
    actual = record.get("actual") or {}
    if actual.get("home") is None or actual.get("away") is None:
        return ""

    consensus = record["consensus"]
    predicted = consensus["score"].replace(" ", "")
    actual_score = f"{actual['home']}-{actual['away']}"
    exact = predicted == actual_score
    predicted_outcome = consensus["outcome"]
    actual_outcome = "HOME" if actual["home"] > actual["away"] else "AWAY" if actual["home"] < actual["away"] else "DRAW"

    return (
        "📊 MAÇ SONUCU\n\n"
        f"⚽ {record['home_team']} - {record['away_team']}\n"
        f"🏁 Gerçek skor: {actual_score}\n"
        f"🎯 AI konsensüs skoru: {predicted}\n"
        f"{'✅ Tam skor tuttu' if exact else '❌ Tam skor tutmadı'}\n"
        f"{'✅ Maç sonucu doğru' if predicted_outcome == actual_outcome else '❌ Maç sonucu yanlış'}"
    )
