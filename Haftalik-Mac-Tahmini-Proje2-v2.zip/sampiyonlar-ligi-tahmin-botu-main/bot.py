from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from ai_pool import run_ai_pool
from consensus_engine import build_consensus
from data_provider import FootballDataClient, FootballDataError, build_team_form, parse_utc
from report_engine import build_result_message, build_telegram_message
from research_engine import research_match


TURKEY_TZ = ZoneInfo("Europe/Istanbul")
MIN_MINUTES_BEFORE = 45
MAX_MINUTES_BEFORE = 60
MATCHES_FILE = Path("match_predictions.json")
SEASON = "2026/27"


def load_predictions() -> dict:
    if not MATCHES_FILE.exists():
        return {}
    try:
        return json.loads(MATCHES_FILE.read_text(encoding="utf-8"))
    except Exception as error:
        print(f"⚠️ {MATCHES_FILE} okunamadı: {error}")
        return {}


def save_predictions(predictions: dict) -> None:
    temp = MATCHES_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(predictions, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(MATCHES_FILE)


def send_telegram_message(message: str) -> None:
    import requests

    response = requests.post(
        f"https://api.telegram.org/bot{os.environ['TELEGRAM_BOT_TOKEN']}/sendMessage",
        data={"chat_id": os.environ["TELEGRAM_CHAT_ID"], "text": message},
        timeout=30,
    )
    response.raise_for_status()


def build_standings_map(standings: list[dict]) -> dict[int, dict]:
    result = {}
    for group in standings:
        if group.get("type") != "TOTAL":
            continue
        for row in group.get("table", []):
            team = row.get("team", {})
            if team.get("id") is not None:
                result[int(team["id"])] = {
                    "position": row.get("position"),
                    "played": row.get("playedGames"),
                    "points": row.get("points"),
                    "goals_for": row.get("goalsFor"),
                    "goals_against": row.get("goalsAgainst"),
                }
    return result


def update_finished_results(predictions: dict, matches: list[dict]) -> bool:
    changed = False
    by_id = {str(match.get("id")): match for match in matches}

    for match_id, record in predictions.items():
        if record.get("actual"):
            continue
        match = by_id.get(str(match_id))
        if not match or match.get("status") != "FINISHED":
            continue
        score = match.get("score", {}).get("fullTime", {})
        if score.get("home") is None or score.get("away") is None:
            continue
        record["actual"] = {
            "home": score["home"],
            "away": score["away"],
            "status": "FINISHED",
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        record["exact_score_correct"] = (
            record.get("consensus", {}).get("score", "").replace(" ", "")
            == f"{score['home']}-{score['away']}"
        )
        predicted_outcome = record.get("consensus", {}).get("outcome")
        actual_outcome = "HOME" if score["home"] > score["away"] else "AWAY" if score["home"] < score["away"] else "DRAW"
        record["outcome_correct"] = predicted_outcome == actual_outcome
        changed = True

    return changed


def main() -> None:
    if not os.environ.get("TELEGRAM_BOT_TOKEN") or not os.environ.get("TELEGRAM_CHAT_ID"):
        raise RuntimeError("Telegram secret'ları eksik.")

    predictions = load_predictions()
    football = FootballDataClient()
    matches = football.get_matches()

    if update_finished_results(predictions, matches):
        save_predictions(predictions)
        print("📊 Bitmiş maç sonuçları arşive işlendi.")

    now_utc = datetime.now(timezone.utc)
    upcoming = []
    for match in matches:
        if match.get("status") not in {"SCHEDULED", "TIMED"}:
            continue
        match_utc = parse_utc(match["utcDate"])
        minutes_until = (match_utc - now_utc).total_seconds() / 60
        if MIN_MINUTES_BEFORE <= minutes_until <= MAX_MINUTES_BEFORE:
            upcoming.append((match, minutes_until))

    print(f"Toplam {len(matches)} Şampiyonlar Ligi maçı bulundu.")
    print(f"Tahmin penceresinde {len(upcoming)} maç var.")

    if not upcoming:
        return

    try:
        standings_map = build_standings_map(football.get_standings())
    except FootballDataError as error:
        print(f"⚠️ Puan durumu alınamadı: {error}")
        standings_map = {}

    research_client = None
    if os.environ.get("GEMINI_API_KEY"):
        from google import genai
        research_client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])

    for match, minutes_until in upcoming:
        match_id = str(match["id"])
        home_team = match["homeTeam"]["name"]
        away_team = match["awayTeam"]["name"]
        match_utc = parse_utc(match["utcDate"])
        match_turkey = match_utc.astimezone(TURKEY_TZ)

        if predictions.get(match_id, {}).get("final_sent"):
            print(f"⏭️ {home_team} - {away_team}: zaten gönderildi.")
            continue

        print(f"\n🔎 Analiz: {home_team} - {away_team} | {minutes_until:.1f} dk kaldı")

        home_id = int(match["homeTeam"]["id"])
        away_id = int(match["awayTeam"]["id"])
        context = {
            "season": SEASON,
            "matchday": match.get("matchday"),
            "stage": match.get("stage"),
            "venue": match.get("venue"),
            "home": {
                "team_id": home_id,
                "standings": standings_map.get(home_id),
            },
            "away": {
                "team_id": away_id,
                "standings": standings_map.get(away_id),
            },
        }

        try:
            home_matches = football.get_team_matches(home_id, match_utc)
            away_matches = football.get_team_matches(away_id, match_utc)
            context["home"]["last_5"] = build_team_form(home_matches, home_id)
            context["away"]["last_5"] = build_team_form(away_matches, away_id)
        except FootballDataError as error:
            print(f"⚠️ Son maç verileri alınamadı: {error}")
            context["data_warning"] = str(error)

        previous = predictions.get(match_id, {}).get("consensus")

        if research_client is None:
            print("⚠️ GEMINI_API_KEY yok; güncel web araştırması yapılamıyor.")
            continue

        try:
            research = research_match(research_client, home_team, away_team, context)
        except Exception as error:
            print(f"⚠️ Güncel araştırma başarısız: {error}")
            continue

        votes = run_ai_pool(home_team, away_team, context, research, previous)
        success_count = sum(1 for vote in votes if vote.success)
        if success_count < 3:
            print(f"🚨 Yetersiz AI başarısı: {success_count}/5. Telegram tahmini gönderilmiyor.")
            continue

        consensus = build_consensus(votes)
        record = {
            "season": SEASON,
            "matchday": match.get("matchday"),
            "match_id": match_id,
            "home_team": home_team,
            "away_team": away_team,
            "match_time": match_turkey.strftime("%d.%m.%Y %H:%M"),
            "prediction_created_at": datetime.now(timezone.utc).isoformat(),
            "minutes_before_match": round(minutes_until, 1),
            "context": context,
            "research": research,
            "ai_votes": [
                {"model": vote.model, "success": vote.success, "result": vote.result, "error": vote.error}
                for vote in votes
            ],
            "consensus": consensus,
            "final_sent": False,
        }

        try:
            send_telegram_message(build_telegram_message(record))
        except Exception as error:
            print(f"⚠️ Telegram hatası: {error}")
            continue

        record["final_sent"] = True
        predictions[match_id] = record
        save_predictions(predictions)
        print("✅ Maç tahmini Telegram'a gönderildi ve arşivlendi.")

    # Sonuçları aynı çalıştırmada tekrar kontrol et; normalde bir sonraki cron'da dolacaktır.
    save_predictions(predictions)


if __name__ == "__main__":
    main()
