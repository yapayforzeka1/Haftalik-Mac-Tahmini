# Haftalık Maç Tahmini

UEFA Şampiyonlar Ligi 2026/27 için maç öncesi çoklu yapay zekâ tahmin botu.

## Akış

1. football-data.org üzerinden fikstür, puan durumu ve takımın son maçları alınır.
2. Gemini Google Search grounding ile güncel haber, sakatlık/ceza, form, xG/xGA, şut, kadro ve taktik araştırması yapılır.
3. Aynı araştırma paketi 5 AI modeline gönderilir.
4. AI oyları sonuç ve skor bazında konsensüse dönüştürülür.
5. En az 3/5 AI başarılıysa Telegram mesajı gönderilir.
6. Tahmin ve araştırma `match_predictions.json` içinde saklanır.
7. Sonraki çalıştırmalarda biten maçların gerçek sonuçları arşive işlenir.

## AI havuzu

- Gemini 3.6 Flash
- Mistral Small Latest
- Groq Qwen 3.6 27B
- Cohere Command A+
- Groq GPT-OSS 120B

## GitHub Secrets

- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`
- `FOOTBALL_DATA_API_KEY`
- `GEMINI_API_KEY`
- `MISTRAL_API_KEY`
- `GROQ_API_KEY`
- `COHERE_API_KEY`

API anahtarları kod içine yazılmamalıdır.
