from ai_pool import AIVote
from consensus_engine import build_consensus
from data_provider import build_team_form


def test_consensus():
    votes = [
        AIVote("A", True, {"outcome": "HOME", "score": "2-1", "confidence": 70, "reasons": ["form"]}),
        AIVote("B", True, {"outcome": "HOME", "score": "2-1", "confidence": 65, "reasons": ["xG"]}),
        AIVote("C", True, {"outcome": "DRAW", "score": "1-1", "confidence": 55, "reasons": ["defense"]}),
        AIVote("D", False, error="429"),
    ]
    result = build_consensus(votes)
    assert result["successful_ai"] == 3
    assert result["outcome"] == "HOME"
    assert result["outcome_share"] == 67
    assert result["score"] == "2-1"


def test_team_form():
    matches = []
    for i, score in enumerate([(2, 1), (1, 1), (0, 2), (3, 0), (1, 0)]):
        matches.append({
            "utcDate": f"2026-08-{20+i:02d}T18:00:00Z",
            "competition": {"name": "Test League"},
            "homeTeam": {"id": 1, "name": "Home"},
            "awayTeam": {"id": 2, "name": "Away"},
            "score": {"fullTime": {"home": score[0], "away": score[1]}},
        })
    form = build_team_form(matches, 1)
    assert form["last_5"] == "W-D-L-W-W"
    assert form["points_last_5"] == 10
    assert form["goals_for_last_5"] == 7
    assert form["goals_against_last_5"] == 4


if __name__ == "__main__":
    test_consensus()
    test_team_form()
    print("CORE TESTS OK")
