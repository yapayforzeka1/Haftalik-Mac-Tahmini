from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any

from google import genai
from google.genai import types


RESEARCH_MODEL = "gemini-3.7-flash"


def _compact(value: Any, max_chars: int = 16000) -> str:
    text = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return text[:max_chars]


def _extract_json(text: str) -> dict[str, Any]:
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, flags=re.S)
        if not match:
            raise ValueError("Araştırma JSON olarak ayrıştırılamadı.")
        return json.loads(match.group(0))


def research_match(
    client: genai.Client,
    home_team: str,
    away_team: str,
    match_context: dict[str, Any],
) -> dict[str, Any]:
    """Fresh web research via Gemini Google Search grounding.

    The model is explicitly asked to cross-check multiple independent sources and
    to mark unavailable/conflicting statistics rather than inventing them.
    """
    prompt = f"""
Bugün {datetime.now(timezone.utc).date().isoformat()}.

UEFA Champions League 2026/27 maç öncesi araştırma analisti ol.
Maç: {home_team} - {away_team}

Aşağıdaki yapılandırılmış futbol verisini temel al:
{_compact(match_context, 18000)}

Web üzerinde GÜNCEL araştırma yap. Özellikle son 60 gün ve son 5 resmi maç bilgilerini
önceliklendir. Mümkün olduğunda en az 3 farklı bağımsız güvenilir kaynağı çapraz kontrol et.
Öncelik: UEFA/club official, güvenilir spor basını, istatistik siteleri (FBref/Understat/Sofascore
veya erişilebilen eşdeğerleri). Kaynaklar çelişirse çelişkiyi açıkça belirt.

Araştır:
- son 5 maç ve form
- gol/gol yeme trendi
- xG/xGA varsa
- şut ve isabetli şut varsa
- iç saha/deplasman performansı
- sakatlıklar ve cezalar
- muhtemel ilk 11 ve önemli eksikler
- oyuncu formu / gol katkısı
- teknik direktör ve taktik yaklaşım
- rakibin oyun tarzı ve eşleşme avantajları
- transfer/squad değişiklikleri
- UEFA durumu, puan ve kalan fikstür bağlamı
- yakın tarihli güvenilir haberler

VERİ UYDURMA. Bir istatistik bulunamazsa null yaz.

Sadece aşağıdaki JSON'u döndür:
{{
  "summary": "en fazla 900 karakterlik maç araştırma özeti",
  "home": {{
    "form": "...",
    "goals_trend": "...",
    "xg_xga": "...",
    "shots": "...",
    "home_away": "...",
    "injuries_suspensions": "...",
    "probable_xi": "...",
    "key_players": "...",
    "tactics": "..."
  }},
  "away": {{
    "form": "...",
    "goals_trend": "...",
    "xg_xga": "...",
    "shots": "...",
    "home_away": "...",
    "injuries_suspensions": "...",
    "probable_xi": "...",
    "key_players": "...",
    "tactics": "..."
  }},
  "comparison": "iki takım arasındaki en önemli 3-5 fark",
  "news": ["..."],
  "conflicts": ["..."],
  "sources": ["kaynak adı - URL"],
  "research_confidence": "HIGH|MEDIUM|LOW"
}}
"""

    config = types.GenerateContentConfig(
        tools=[types.Tool(google_search=types.GoogleSearch())],
        response_mime_type="application/json",
        temperature=0.2,
        max_output_tokens=5000,
    )

    response = client.models.generate_content(
        model=RESEARCH_MODEL,
        contents=prompt,
        config=config,
    )

    text = (response.text or "").strip()
    result = _extract_json(text)
    result["researched_at"] = datetime.now(timezone.utc).isoformat()
    return result
