from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class AIVote:
    model: str
    success: bool
    result: dict[str, Any] | None = None
    error: str | None = None


GEMINI_MODEL = "gemini-3.6-flash"
MISTRAL_MODEL = "mistral-small-latest"
GROQ_QWEN_MODEL = "qwen/qwen3.6-27b"
GROQ_120B_MODEL = "openai/gpt-oss-120b"
COHERE_MODEL = "command-a-plus-05-2026"


def _extract_json(text: str) -> dict[str, Any]:
    text = (text or "").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, flags=re.S)
        if not match:
            raise ValueError("AI cevabı JSON değil.")
        return json.loads(match.group(0))


def _normalize(result: dict[str, Any], home: str, away: str) -> dict[str, Any]:
    outcome = str(result.get("outcome", "")).upper().strip()
    if outcome not in {"HOME", "DRAW", "AWAY"}:
        raise ValueError(f"Geçersiz outcome: {outcome}")

    score = str(result.get("score", "")).strip()
    if not re.fullmatch(r"\d+\s*-\s*\d+", score):
        raise ValueError(f"Geçersiz skor: {score}")

    confidence = int(result.get("confidence", 0))
    if not 0 <= confidence <= 100:
        raise ValueError("confidence 0-100 aralığında olmalı.")

    reasons = result.get("reasons", [])
    if not isinstance(reasons, list):
        reasons = [str(reasons)]

    return {
        "home_team": home,
        "away_team": away,
        "outcome": outcome,
        "score": score,
        "confidence": confidence,
        "reasons": [str(item) for item in reasons[:5]],
        "change_vs_previous": str(result.get("change_vs_previous", "")),
    }


def build_prompt(
    home: str,
    away: str,
    match_context: dict[str, Any],
    research: dict[str, Any],
    previous: dict[str, Any] | None,
) -> str:
    previous_text = json.dumps(previous, ensure_ascii=False) if previous else "Yok"
    return f"""
Sen UEFA Champions League maç analisti olan bir yapay zekasın.

Maç: {home} - {away}

Futbol verisi:
{json.dumps(match_context, ensure_ascii=False, separators=(",", ":"))}

Güncel araştırma:
{json.dumps(research, ensure_ascii=False, separators=(",", ":"))}

Önceki haftadaki tahmin:
{previous_text}

Verileri birlikte değerlendir. Özellikle form, gol trendi, xG/xGA, şutlar,
sakatlık/ceza, muhtemel XI, taktik eşleşme, iç/dış saha, UEFA sıralama durumu,
fikstür yoğunluğu ve güncel haberleri dikkate al.

ÖNEMLİ: confidence gerçek olasılık değildir. Sadece senin bu tahmine verdiğin
öznel güven seviyesidir. Sistem final mesajında AI oylarını konsensüs olarak gösterecek.

Sadece JSON döndür:
{{
  "outcome": "HOME|DRAW|AWAY",
  "score": "2-1",
  "confidence": 0,
  "reasons": ["kısa neden 1", "kısa neden 2", "kısa neden 3"],
  "change_vs_previous": "önceki tahminden farklıysa neden; aynıysa neden korundu"
}}
"""


def _gemini(prompt: str) -> str:
    from google import genai
    client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config={"response_mime_type": "application/json", "temperature": 0.2, "max_output_tokens": 1200},
    )
    return response.text or ""


def _mistral(prompt: str) -> str:
    from mistralai.client import Mistral
    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    response = client.chat.complete(
        model=MISTRAL_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
        response_format={"type": "json_object"},
    )
    return response.choices[0].message.content or ""


def _groq(prompt: str, model: str) -> str:
    from groq import Groq
    client = Groq(api_key=os.environ["GROQ_API_KEY"])
    kwargs: dict[str, Any] = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.1,
        "max_completion_tokens": 1200,
        "response_format": {"type": "json_object"},
        "reasoning_effort": "low" if model == GROQ_120B_MODEL else "none",
    }
    response = client.chat.completions.create(**kwargs)
    return response.choices[0].message.content or ""


def _cohere(prompt: str) -> str:
    import cohere
    client = cohere.ClientV2(api_key=os.environ["COHERE_API_KEY"])
    response = client.chat(
        model=COHERE_MODEL,
        messages=[{"role": "user", "content": prompt}],
    )
    parts = []
    for block in getattr(response.message, "content", []) or []:
        if getattr(block, "type", "") == "text" and getattr(block, "text", ""):
            parts.append(block.text)
    return "\n".join(parts)


def run_ai_pool(
    home: str,
    away: str,
    match_context: dict[str, Any],
    research: dict[str, Any],
    previous: dict[str, Any] | None,
) -> list[AIVote]:
    prompt = build_prompt(home, away, match_context, research, previous)
    providers: list[tuple[str, Callable[[str], str], str]] = [
        ("Gemini 3.6 Flash", _gemini, "GEMINI_API_KEY"),
        ("Mistral Small Latest", _mistral, "MISTRAL_API_KEY"),
        ("Groq Qwen 3.6 27B", lambda p: _groq(p, GROQ_QWEN_MODEL), "GROQ_API_KEY"),
        ("Cohere Command A+", _cohere, "COHERE_API_KEY"),
        ("Groq GPT-OSS 120B", lambda p: _groq(p, GROQ_120B_MODEL), "GROQ_API_KEY"),
    ]

    votes: list[AIVote] = []
    for name, call, key_name in providers:
        if not os.environ.get(key_name):
            votes.append(AIVote(name, False, error=f"{key_name} eksik"))
            print(f"⚠️ {name}: {key_name} eksik, atlandı.")
            continue
        try:
            raw = call(prompt)
            parsed = _normalize(_extract_json(raw), home, away)
            votes.append(AIVote(name, True, parsed))
            print(f"✅ {name}: {parsed['outcome']} / {parsed['score']}")
        except Exception as error:
            # 429/TPM gibi sağlayıcı hatalarında gereksiz retry yok.
            votes.append(AIVote(name, False, error=str(error)))
            print(f"⚠️ {name} başarısız: {error}")
    return votes
