from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any

from ai_pool import AIVote


def build_consensus(votes: list[AIVote]) -> dict[str, Any]:
    successful = [vote for vote in votes if vote.success and vote.result]
    if not successful:
        raise RuntimeError("Hiçbir AI başarılı sonuç üretmedi.")

    outcome_counts = Counter(vote.result["outcome"] for vote in successful)
    score_counts = Counter(vote.result["score"] for vote in successful)
    outcome_order = {"HOME": 0, "DRAW": 1, "AWAY": 2}
    outcome, outcome_votes = sorted(
        outcome_counts.items(), key=lambda item: (-item[1], outcome_order[item[0]])
    )[0]
    score, score_votes = score_counts.most_common(1)[0]

    reasons: dict[str, list[str]] = defaultdict(list)
    for vote in successful:
        for reason in vote.result.get("reasons", []):
            if reason not in reasons[vote.result["outcome"]]:
                reasons[vote.result["outcome"]].append(reason)

    failed = [
        {"model": vote.model, "error": vote.error}
        for vote in votes
        if not vote.success
    ]

    return {
        "successful_ai": len(successful),
        "total_ai": len(votes),
        "outcome": outcome,
        "outcome_votes": outcome_votes,
        "outcome_share": round(outcome_votes / len(successful) * 100),
        "score": score,
        "score_votes": score_votes,
        "score_share": round(score_votes / len(successful) * 100),
        "all_outcomes": dict(outcome_counts),
        "all_scores": dict(score_counts),
        "reasons_by_outcome": {key: value[:5] for key, value in reasons.items()},
        "failed_ai": failed,
    }


def outcome_label(outcome: str, home: str, away: str) -> str:
    return {"HOME": home, "DRAW": "Beraberlik", "AWAY": away}[outcome]
